package com.test;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.apache.poi.ss.usermodel.Cell;

import com.page.CartPage;
import com.page.ConfirmationPage;
import com.page.HomePage;
import com.page.LoginPage;
import com.page.OrderDetailsPage;
import com.page.PaymentPage;
import com.page.ProductPage;
//import com.utilitydemo.*;
import com.utils.ReportManager;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class PetStoreTest {
	  private   WebDriver driver;
	  private  LoginPage loginPage;
	  private  HomePage homePage;
	  private  ProductPage productPage;
	  private CartPage cartPage;
	  private PaymentPage paymentPage;
	  private ConfirmationPage confirmationPage;
	  private OrderDetailsPage orderConfirmationPage;
	     
	 @BeforeSuite
	 public void startExtentReport() {
		 ReportManager.startReport();
	 }
	     
	     
    @BeforeTest
    @Parameters("browser")
    public void setUp(String browser){
       
	  if(browser.equalsIgnoreCase("chrome")) {
			//System.setProperty("webdriver.chrome.driver","C:/Driver/chromedriver-win64/chromedriver.exe");
		    WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.get("https://petstore.octoperf.com/actions/Account.action");
		}
		else if(browser.equalsIgnoreCase("edge")) {
			//System.setProperty("webdriver.edge.driver", "C:/WebDriverofEdge/msedgedriver.exe");  //C:\WebDriverofEdge
			WebDriverManager.edgedriver().setup();
			driver= new EdgeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
			driver.get("https://petstore.octoperf.com/actions/Account.action");
		}
		else {
			throw new RuntimeException("Browser is not correct");
		}
       
    }

    @Test  (dataProvider = "loginData")
    public void testOrderFlow(String username, String password)  {
    	 // Initialize page objects for use in the test
    	//String username="j2ee"; String password="j2ee";
    	ReportManager.startTest("Login Test");
    	try {
        loginPage = new LoginPage(driver);
        loginPage.login(username, password);
        homePage = new HomePage(driver);
        productPage = new ProductPage(driver);
        cartPage = new CartPage(driver);
        paymentPage = new PaymentPage(driver);
        confirmationPage = new ConfirmationPage(driver);
        orderConfirmationPage=new OrderDetailsPage(driver);
       
        Assert.assertEquals(homePage.isLoggedIn(), true, "Login failed");
        
        if(homePage.isLoggedIn()==true) {
        	ReportManager.logPass("User successfully Loggedin");
        }
        
        homePage.selectCategory("FISH");
        productPage.selectProduct("FI-SW-01"); 

        cartPage.addToCart();
        cartPage.proceedToCheckout();

        Assert.assertEquals(paymentPage.isPaymentPage(), true, "Payment page not displayed");
        paymentPage.fillPaymentDetailsAndContinue();

        confirmationPage.confirmOrder();
        Assert.assertEquals(confirmationPage.isOrderConfirmed(), true, "Order not confirmed message missing");
         
        Assert.assertEquals(orderConfirmationPage.getConfirmationMessage().trim(), "Thank you, your order has been submitted.", "Confirmation message does not match!");
    	}catch(Exception e) {
    		ReportManager.logFail("Login failed: " + e.getMessage());
    	}
        
    }
  
	@DataProvider(name="loginData")
	public Object[][] getCellData() throws IOException{
		
		
		FileInputStream file = new FileInputStream("C:\\ExcelData\\UserDetails.xlsx");
		
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet s= wb.getSheet("Sheet1");
		
		int rowcount = s.getLastRowNum()+1;
		int cellcount=s.getRow(0).getLastCellNum();
		
		Object[][] data = new Object[rowcount][cellcount];
		
		for(int i=0;i<rowcount;i++) {
			Row r= s.getRow(i);
			for(int j=0;j<cellcount;j++) {
				Cell c = r.getCell(j);
				data[i][j]=c.getStringCellValue();
			}
		}
		wb.close();
		return data;
	}



    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }   
     @AfterSuite
   	 public void endExtentReport() {
    	 ReportManager.endReport();
   	 }  
        
   
}
