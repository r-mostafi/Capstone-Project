package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrderDetailsPage {
	
	private WebDriver driver;

     public OrderDetailsPage(WebDriver driver) {
         this.driver = driver;
     }
    
     private  By confirmationMessage = By.xpath("//*[contains(text(),'Thank you, your order has been submitted.')]");

    public String getConfirmationMessage() {
        return driver.findElement(confirmationMessage).getText();
    }
   
}
