package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
	private WebDriver driver;
    

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }
   
    public void selectProduct(String productId) {
    	
        //driver.findElement(By.xpath("//a[contains(@href,'" + productId + "')]")).click();
    	driver.findElement(By.partialLinkText(productId)).click();
    	
    }
}
