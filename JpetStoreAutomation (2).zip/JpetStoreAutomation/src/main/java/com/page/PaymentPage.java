package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class PaymentPage {
    private WebDriver driver;

    public PaymentPage(WebDriver driver) {
        this.driver = driver;
    }
    private   By dropdown=By.name("order.cardType");
    private  By cardNo=By.name("order.creditCard");
    private  By expiryDate=By.name("order.expiryDate");
    private  By fName=By.name("order.billToFirstName"); 
    private  By lName=By.name("order.billToLastName"); 
    private  By add1=By.name("order.billAddress1"); 
    private  By add2=By.name("order.billAddress2"); 
    private  By city=By.name("order.billCity"); 
    private  By state=By.name("order.billState");
    private By country=By.name("order.billCountry");
    
    public boolean isPaymentPage() {
        return driver.getPageSource().contains("Payment Details");
    }

    public void fillPaymentDetailsAndContinue() {
        Select select=new Select(driver.findElement(dropdown));
        select.selectByValue("MasterCard");
        
        driver.findElement(cardNo).clear();
        driver.findElement(cardNo).sendKeys("1111111111");
        
        driver.findElement(expiryDate).clear();
        driver.findElement(expiryDate).sendKeys("05/2035");
        
        driver.findElement(fName).clear();
        driver.findElement(fName).sendKeys("J2ee");
        
        driver.findElement(lName).clear();
        driver.findElement(lName).sendKeys("J1ee");
        
        driver.findElement(add1).clear();
        driver.findElement(add1).sendKeys("India,Noida,SEC126");
        
        driver.findElement(add2).clear();
        driver.findElement(add2).sendKeys("India,Noida,SEC126");
        
        driver.findElement(city).clear();
        driver.findElement(city).sendKeys("Noida");
        
        driver.findElement(state).clear();
        driver.findElement(state).sendKeys("UP");
        
        driver.findElement(country).clear();
        driver.findElement(country).sendKeys("India");
        
        
        
        driver.findElement(By.xpath("//input[@value='Continue']")).click();
    }

}
