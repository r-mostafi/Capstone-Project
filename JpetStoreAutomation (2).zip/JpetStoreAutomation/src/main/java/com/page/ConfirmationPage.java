package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ConfirmationPage {
	private  WebDriver driver;

	    public ConfirmationPage(WebDriver driver) {
	        this.driver = driver;
	    }

	    public void confirmOrder() {
	        driver.findElement(By.xpath("//a[text()='Confirm']")).click();
	    }

	    public boolean isOrderConfirmed() {
	        return driver.getPageSource().contains("Thank you, your order has been submitted.");
	    }
}
