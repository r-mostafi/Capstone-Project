package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	private  WebDriver driver;

	    public HomePage(WebDriver driver) {
	        this.driver = driver;
	    }
	   
	   public boolean isLoggedIn() {
	        // "Sign Out" appears only after login
	        return driver.getPageSource().contains("Sign Out");
	    } 
	   
	   private   By fish=By.xpath("//*[@id=\"SidebarContent\"]/a[1]/img");
	   private   By dog=By.xpath("//*[@id=\"SidebarContent\"]/a[2]/img");
	   private   By cat=By.xpath("//*[@id=\"SidebarContent\"]/a[3]/img");
	   private   By reptile=By.xpath("//*[@id=\"SidebarContent\"]/a[4]/img");
	   private  By bird=By.xpath("//*[@id=\"SidebarContent\"]/a[5]/img");
	   
	    public void selectCategory(String category) {
	    	category=category.toLowerCase();
	        switch(category) {
	        case "fish": driver.findElement(fish).click();
	                     break;
	                     
	        case "dog": driver.findElement(dog).click();
                        break;
                     
	        case "cat": driver.findElement(cat).click();
                       break;
                       
	        case "reptile": driver.findElement(reptile).click();
                            break;
                            
	        case "bird": driver.findElement(bird).click();
                         break;
	        	
	        }
	    }


}
