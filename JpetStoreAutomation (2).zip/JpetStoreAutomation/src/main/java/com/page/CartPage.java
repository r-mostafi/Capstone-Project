package com.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
	private WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public void addToCart() {
        driver.findElement(By.xpath("//a[text()='Add to Cart']")).click();
    }

    public void proceedToCheckout() {
        driver.findElement(By.xpath("//a[text()='Proceed to Checkout']")).click();
    }

}
