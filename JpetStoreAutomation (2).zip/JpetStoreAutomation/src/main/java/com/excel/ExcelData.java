package com.excel;
/*
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;



import java.io.*;

public class ExcelData {
	
	@DataProvider(name="loginData")
	public Object[][] getCellData() throws IOException{
		
		
		FileInputStream file = new FileInputStream("C:\\ExcelDemoSelenium\\sampledoc.xlsx");Credential
		
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet s= wb.getSheet("Sheet1");
		
		int rowcount = s.getLastRowNum()+1;
		int cellcount=s.getRow(0).getLastCellNum();
		
		Object[][] data = new Object[rowcount][cellcount];
		
		for(int i=0;i<rowcount;i++) {
			Row r= s.getRow(i);
			for(int j=0;j<cellcount;j++) {
				Cell c = r.getCell(j);
				data[i][j]=c.getStringCellValue();
			}
		}
		wb.close();
		return data;
	}

}
*/



